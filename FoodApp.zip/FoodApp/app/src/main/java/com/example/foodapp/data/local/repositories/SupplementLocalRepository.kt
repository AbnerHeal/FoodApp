package com.example.foodapp.data.local.repositories

import com.example.foodapp.data.entities.SupplementEntity
import com.example.foodapp.data.local.dao.SupplementDao
import com.example.foodapp.data.mapers.toModel
import javax.inject.Inject

class SupplementLocalRepository @Inject constructor( //Inyectar FoodDao
    private val supplementDao:SupplementDao
) { /*
    fun getSupplements()=supplementDao.getSupplements()
    suspend fun insertSupplement(supplementEntity: SupplementEntity)=supplementDao.insert(supplementEntity.toModel())
    suspend fun clearSupplements()=supplementDao.clearSupplements()
    suspend fun deleteSupplementById(id:String)=supplementDao.deleteSupplementById(id) */
}