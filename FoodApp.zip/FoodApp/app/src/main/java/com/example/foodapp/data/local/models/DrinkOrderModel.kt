package com.example.foodapp.data.local.models

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.foodapp.data.models.DrinkDto

@Entity
data class DrinkOrderModel (
    @PrimaryKey
    val drinks: List<String>? = null,
)