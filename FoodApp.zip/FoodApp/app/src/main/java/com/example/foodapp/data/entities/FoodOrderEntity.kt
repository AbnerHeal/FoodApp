package com.example.foodapp.data.entities

import com.example.foodapp.data.models.FoodDto
import com.google.gson.annotations.SerializedName

data class FoodOrderEntity(
    val foods: List<String>? = null, //lista por ids de orden de comidas
)