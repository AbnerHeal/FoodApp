package com.example.foodapp.presentation.models

import android.os.Parcelable
import com.example.foodapp.data.entities.SupplementEntity
import kotlinx.parcelize.Parcelize

@Parcelize
data class Order(
    val id: String,
    val name: String,
    val price: Number,
    val image: String,
    val supplements: List<Supplement>? = null
):Parcelable