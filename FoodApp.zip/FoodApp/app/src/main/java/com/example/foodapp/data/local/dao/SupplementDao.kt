package com.example.foodapp.data.local.dao

import androidx.lifecycle.LiveData
import androidx.paging.PagingSource
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.foodapp.data.local.models.DessertModel
import com.example.foodapp.data.local.models.SupplementModel

@Dao
interface SupplementDao {
    @Query("Select * From SupplementModel")
    fun getSupplements(): LiveData<List<DessertModel>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(supplement:SupplementModel)

    @Query("DELETE FROM SupplementModel")
    suspend fun clearSupplements()

    @Query("DELETE FROM SupplementModel where id=:id")
    suspend fun deleteSupplementById(id:String)
}