package com.example.foodapp.di

import com.example.foodapp.data.remote.api.FoodService
import com.google.gson.GsonBuilder
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import okhttp3.HttpUrl
import okhttp3.HttpUrl.Companion.toHttpUrl
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import javax.inject.Named
import javax.inject.Singleton

//di:dependencies injections
@Module //indicamos a hilt que es un modulo para RETROFIT, el arroba es un decorador/ anotador
@InstallIn(SingletonComponent::class) //le decimos donde instalara estas instancias o dependencias del modulo  (ambos van de la mano module-install)

//singleton component donde habra instancias
class  RemoteModule {
    @Provides
    @Singleton //creamos una instancia de Gson
    //para poder convertir los json a objetos java y la app pueda leerlos
    fun provideGson()=GsonBuilder().apply { //
        setDateFormat("yyyy-mm-dd'T':HH:mm:ss.SSS'Z'") //esto se usa con retrofit
        setLenient()
    }.create()

    @Provides //declaramos el URLBASE para la llamada retrofit
    @Named("BaseUrl") //asignamos un nombre
    fun provideBaseUrl()="https://store-api-food.herokuapp.com/api/v1/".toHttpUrl() //lo convertimos a url

    @Provides //le entrara nuestro url base y regresara retrofit
    @Singleton //para hacer solicitud al Rest y obtener el objeto retrofit (lo devuelve)
    fun provideRetrofit(@Named("BaseUrl") baseUrl:HttpUrl):Retrofit{
        return Retrofit.Builder()
            .addConverterFactory(GsonConverterFactory.create())
            .baseUrl(baseUrl)
            .build()
    }//hace la funcion de la clase ADAPTER

    @Provides//es la conexion entre el adaptador y la interfaz api
    @Singleton //inyectamos por constructor el objeto retrofit y asi obtendremos los metodos del apiservice(foodservice)
    fun provideFoodService(retrofit: Retrofit):FoodService=retrofit.create(FoodService::class.java)// devuelve un food service que se crea con retrofit
    //es decir un objeto de la interfaz de API

}