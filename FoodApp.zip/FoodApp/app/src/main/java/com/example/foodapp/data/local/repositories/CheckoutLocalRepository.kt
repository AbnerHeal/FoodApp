package com.example.foodapp.data.local.repositories

import com.example.foodapp.data.entities.CheckoutEntity
import com.example.foodapp.data.local.dao.CheckoutDao
import com.example.foodapp.data.mapers.toModel
import javax.inject.Inject

//almacena datos del checkout

class CheckoutLocalRepository @Inject constructor( //Inyectamos por construcctor un Dao
    private val checkoutDao: CheckoutDao
) {
    /*fun getCheckouts()=checkoutDao.getCheckouts() //hacemos uso de la funcion para obtener los checkouts
    suspend fun insertCheckout(checkoutEntity: CheckoutEntity)=checkoutDao.insert(checkoutEntity.toModel())
    suspend fun clearCheckouts()=checkoutDao.clearCheckout()
    suspend fun deleteCheckoutById(id:String)=checkoutDao.deleteCheckoutById(id)*/
}