package com.example.foodapp.presentation.ui.drink

import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.foodapp.data.entities.DrinkEntity
import com.example.foodapp.data.entities.FoodEntity
import com.example.foodapp.presentation.ui.food.FoodAdapter
import com.example.foodapp.ui_ktx.notifyChanged

class DrinkAdapter(
    private val listener: OnClickListener
): RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    private var drinks:List<DrinkEntity> by notifyChanged(
        areContentsTheSame = {old,new->old.isClicked != new.isClicked}
        //notifica cambios cuando old y new sean diferentes
    )

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): DrinkViewHolder =
        DrinkViewHolder.create(parent)

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        if(holder is DrinkViewHolder){
            val drink=drinks[position]
            holder.bindTo(drink, listener)
        }
    }

    override fun getItemCount(): Int =drinks.size

    fun addDrinks(drinks:List<DrinkEntity>){
        this.drinks=drinks
    }

    interface OnClickListener {
        fun onClick(drinkEntity: DrinkEntity)
    }
}