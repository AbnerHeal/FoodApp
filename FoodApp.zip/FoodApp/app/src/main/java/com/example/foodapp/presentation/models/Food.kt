package com.example.foodapp.presentation.models

import android.os.Parcelable
import kotlinx.parcelize.Parcelize


@Parcelize // modelo para usar en navegation y mostrarlos en los fragments
data class Food(
    val id: String,
    val name: String,
    val price: Number,
    val image: String,
    val supplements: List<Supplement>? = null,
    var isClicked: Boolean = false
):Parcelable