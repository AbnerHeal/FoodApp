package com.example.foodapp.data.entities

import com.example.foodapp.data.models.DessertOrderDto
import com.example.foodapp.data.models.DrinkOrderDto
import com.example.foodapp.data.models.FoodOrderDto
import com.google.gson.annotations.SerializedName

data class CheckoutEntity(
    val id: String?="",//id de la orden
    val foodOrder: FoodOrderEntity?=null, //tendra una orden de foods
    val drinkOrder: DrinkOrderEntity?=null, //tendra una orden de drinks
    val dessertOrder: DessertOrderEntity?=null, // tenddra una orden de desserts
    val totalPrice:Number?=null, //la suma que haremos para calcular el precio total de la orden
)
