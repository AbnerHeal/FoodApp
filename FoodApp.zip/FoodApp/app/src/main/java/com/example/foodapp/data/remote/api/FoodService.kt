package com.example.foodapp.data.remote.api


import com.example.foodapp.data.models.*
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST

//interfaz de la llamada a los datos de mi API REST (es como mi dao)

//aqui se definen los diferentes metodos que se usan para las transacciones de red
interface FoodService { //le llamamos servicio de comida
    @GET("getCheckouts")
    suspend fun getCheckouts():List<CheckoutDto> //solicitamos los checkouts

    @POST("createCheckout")//especifica la URL secundaria para nuestra URL BASE
    suspend fun createCheckouts(@Body body: CheckoutDto):CheckoutDto //anadimos lo que contiene el checkout,
    // como tipo checkoutDto (mi lista de mi orden)

    @GET("getFoods")//especifica la URL secundaria para nuestra URL BASE
    suspend fun getFoods():List<FoodDto> //solicitamos la lista de los items de comida disponibles

    @GET("getSupplements")
    suspend fun getSupplements():List<SupplementDto> //solicitamos la lista de los items de suplementos disponibles

    @GET("getDrinks")
    suspend fun getDrinks():List<DrinkDto> //solicitamos la lista de los items de bebidas disponibles

    @GET("getDesserts")
    suspend fun getDesserts():List<DessertDto> //solicitamos la lista de los items de postres disponibles

    @GET("getFlavors")
    suspend fun getFlavors():List<FlavorDto> //solicitamos la lista de los items de sabores disponibles
}