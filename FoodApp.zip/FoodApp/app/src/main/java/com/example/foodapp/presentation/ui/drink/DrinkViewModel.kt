package com.example.foodapp.presentation.ui.drink

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.foodapp.data.entities.DrinkEntity
import com.example.foodapp.data.entities.FoodEntity
import com.example.foodapp.data.local.repositories.DrinkLocalRepository
import com.example.foodapp.data.remote.repositories.FoodRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Dispatchers.IO
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class DrinkViewModel @Inject constructor(
    private val repository: FoodRepository,
    private val localRepository: DrinkLocalRepository //para agregar al carrito
):ViewModel(){
    private val _drinks= MutableLiveData<List<DrinkEntity>>()
    val drinks= _drinks

    private val _isLoading = MutableLiveData<Boolean>() //observara cuando empiece a cargar (true o false)
    val isLoading = _isLoading //inicia en false

    fun getDrinks()=viewModelScope.launch(Dispatchers.IO){ //hilo secundario
        startLoading()
        repository.getDrinks().also {
            viewModelScope.launch(Dispatchers.Main){
                stopLoading()
                _drinks.setValue(it)
            }
        }//cuando recupere hace lo que esta dentro
    }

    private fun startLoading() = viewModelScope.launch(Dispatchers.Main) { //hilo principal porque mostraremos el progressbart
        _isLoading.value = true
    }

    private fun stopLoading() {//para cambiar el valor y pase a false
        _isLoading.value = false
    }
    fun onSaveDrink(drinkEntity: DrinkEntity)= viewModelScope.launch(IO){
        val drink = localRepository.getDrinkById(drinkEntity.id)
        if (drink != null) localRepository.deleteDrinkById(drinkEntity.id)
        else localRepository.insertDrink(drinkEntity)
    }


    fun onDrinkClicked(drinkEntity: DrinkEntity){
        val drinks = _drinks.value?.toMutableList()
        drinkEntity.isClicked = !drinkEntity.isClicked//para que se pueda seleecionar y deseleccionar
        val index = drinks?.indexOf(drinkEntity)
        drinks?.set(index!!, drinkEntity)
        _drinks.value = drinks?.toList()
    }
}