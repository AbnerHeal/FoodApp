package com.example.foodapp.data.local.models

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.foodapp.data.models.FoodDto

@Entity
data class FoodOrderModel(
    @PrimaryKey
    val foods: List<String>? = null,
)