package com.example.foodapp.data.local.repositories

import com.example.foodapp.data.entities.DessertEntity
import com.example.foodapp.data.entities.FoodEntity
import com.example.foodapp.data.local.dao.DessertDao
import com.example.foodapp.data.local.dao.FoodDao
import com.example.foodapp.data.mapers.toModel
import javax.inject.Inject

class DessertLocalRepository @Inject constructor( //Inyectar Dao por medio de constructor
    private val dessertDao: DessertDao
) {
    fun getDesserts()=dessertDao.getDesserts() //hacemos una funcion que sea igual a la instancia de getDesserts
    suspend fun insertDessert(dessertEntity: DessertEntity)=dessertDao.insert(dessertEntity.toModel()) //le pasamos el dessertentity y lo convertimos a model porque estamos en ROOM
    suspend fun clearDesserts()=dessertDao.clearDesserts()//limpiamos dessert en caso de que ya no sea selleccionado
    //suspend fun deleteDessertById(id:String)=dessertDao.deleteDessertById(id)
}