package com.example.foodapp.data.local.repositories

import com.example.foodapp.data.entities.FoodEntity
import com.example.foodapp.data.local.dao.FoodDao
import com.example.foodapp.data.mapers.toModel
import javax.inject.Inject
//almaceno las funciones para los datos de mi food ROOM
//capa de abstaccion para SQLlite y accede a la base de datos

//sirve como una unica fuente para los datos de la app y organiza las fuentes de los datos
class FoodLocalRepository @Inject constructor( //Inyectar FoodDao
    private val foodDao:FoodDao
) {//trabajamos con model en ROOM
    fun getFoods()=foodDao.getFoods() //solo un objeto el Live Data
    suspend fun insertFood(foodEntity:FoodEntity)=foodDao.insert(foodEntity.toModel()) //usamos mappers
    suspend fun clearFoods()=foodDao.clearFoods()
    //suspend fun deleteFoodById(id:String)=foodDao.deleteFoodById(id) // no se usa debidop a que no se crea una list, solo se pasa un solo item
}

//ROOM Database get DAO, DAO get ENTITYS from db and persist changes back to db, ENTITYS get/set values