package com.example.foodapp.data.local.repositories

import com.example.foodapp.data.entities.DrinkEntity
import com.example.foodapp.data.local.dao.DrinkDao
import com.example.foodapp.data.mapers.toModel
import javax.inject.Inject

class DrinkLocalRepository @Inject constructor( //Inyectar Dao
    private val drinkDao: DrinkDao
) {
    //aqui si se usan todas debido a que se puede seleecionar una o mas y se necesitan borrar una lista en el checkout
    fun getDrinks()=drinkDao.getDrinks()
    fun getDrinkById(id:String) =drinkDao.getDrinkById(id)
    suspend fun insertDrink(drinkEntity: DrinkEntity)=drinkDao.insert(drinkEntity.toModel())
    suspend fun clearDrinks()=drinkDao.clearDrinks()
    suspend fun deleteDrinkById(id:String)=drinkDao.deleteDrinkById(id)
}