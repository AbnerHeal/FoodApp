package com.example.foodapp.data.remote.repositories

import com.example.foodapp.data.mapers.toEntity
import com.example.foodapp.data.models.CheckoutDto
import com.example.foodapp.data.remote.api.FoodService
import javax.inject.Inject

//mi repositorio donde guardare las funciones o lo que recupere del API rest RETROFIT
//organiza todas las fuentes de datos y sirve como la unica fuente de verdad para los datos

class FoodRepository @Inject constructor( //inyecta a foood repositories el food services
    private val foodService: FoodService
) {// los pasamos a Entity para poder mostrarlo y es el formato en como trabajamos aqui en la app
   // suspend fun getCheckouts()=foodService.getCheckouts().map { checkoutDto -> checkoutDto.toEntity()  } //se mapean porque conseguimos una lista de objetos
    suspend fun createCheckouts(checkoutDto: CheckoutDto)=foodService.createCheckouts(checkoutDto).toEntity()//crea para usar con POST y pasa a entity
    suspend fun getFoods()=foodService.getFoods().map { foodDto -> foodDto.toEntity() } //mapeamos pasamos a entity para presentar a usuario
    suspend fun getSupplements()=foodService.getSupplements().map { supplementDto -> supplementDto.toEntity()  }
    suspend fun getDrinks()=foodService.getDrinks().map{drinkDto -> drinkDto.toEntity()  }
    suspend fun getDesserts()=foodService.getDesserts().map {dessertDto -> dessertDto.toEntity()  }
    suspend fun getFlavors()=foodService.getFlavors().map { flavorDto -> flavorDto.toEntity()  }
}//todos estos metodos se realizan en el hilo secundario