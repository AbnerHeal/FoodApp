package com.example.foodapp.data.local.models

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.foodapp.data.models.DessertOrderDto
import com.example.foodapp.data.models.DrinkOrderDto
import com.example.foodapp.data.models.FoodOrderDto

//ROOM
//room decorador ENTIDADES DE ROOM con esas trabajare dentro de room
@Entity
data class CheckoutModel(
    @PrimaryKey//indica tu clave primaria, id
    val id: String="",
    val foodOrder: FoodOrderModel?=null,
    val drinkOrder: DrinkOrderModel?=null,
    val dessertOrder: DessertOrderModel?=null,
    val totalPrice: Double?=null
)

