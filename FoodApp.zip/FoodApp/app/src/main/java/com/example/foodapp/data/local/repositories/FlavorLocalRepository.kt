package com.example.foodapp.data.local.repositories

import com.example.foodapp.data.entities.FlavorEntity
import com.example.foodapp.data.local.dao.FlavorDao
import com.example.foodapp.data.mapers.toModel
import javax.inject.Inject

class FlavorLocalRepository @Inject constructor( //Inyectar FoodDao
    private val flavorDao: FlavorDao
) { /*
    fun getFlavors()=flavorDao.getFlavors()
    suspend fun insertFlavor(flavorEntity: FlavorEntity)=flavorDao.insert(flavorEntity.toModel())
    suspend fun clearFlavors()=flavorDao.clearFlavors()
    suspend fun deleteFlavorById(id:String)=flavorDao.deleteFlavorById(id)
*/}