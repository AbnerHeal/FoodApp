package com.example.foodapp.data.local.converters

import androidx.room.TypeConverter
import com.example.foodapp.data.local.models.*
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
//base de datos sql, solo maneja valores primitivos (json format)
//Sql lenguaje gestor para el manejo de informacion en base de datos y las relaciones entre ellos


//convierte de lista a json y json  a listas porque room lo necesita
// y anade los datos convirtiendolos a json para que el sql los lea

class FoodConverter {  //se llama asi, pero son convertidores para todas las categorias
    //*************************FOODS
    /*
    @TypeConverter
    fun fromFoodsToJson(foods:List<FoodModel>) :String { //entra una lista de food y devuelve el string de json
        val type = object  : TypeToken<List<FoodModel>>() {}.type
        return  Gson().toJson(foods, type)
    }

    @TypeConverter
    fun toFoodList(json:String):List<FoodModel>{ //entra un json y devuelve la lista que usaremos en room
        val type = object  : TypeToken<List<FoodModel>>() {}.type
        return Gson().fromJson(json, type)
    }
     */

    //*************************DRINKS
    /*
    @TypeConverter
    fun fromDrinksToJson(drinks:List<DrinkModel>) :String {
        val type = object  : TypeToken<List<DrinkModel>>() {}.type
        return  Gson().toJson(drinks, type)
    }

    @TypeConverter
    fun toDrinkList(json:String):List<DrinkModel>{
        val type = object  : TypeToken<List<DrinkModel>>() {}.type
        return Gson().fromJson(json, type)
    }

     */
    //*************************DESSERTS
    /*
    @TypeConverter
    fun fromDessertsToJson(desserts:List<DessertModel>) :String {
        val type = object  : TypeToken<List<DessertModel>>() {}.type
        return  Gson().toJson(desserts, type)
    }

    @TypeConverter
    fun toDessertList(json:String):List<DessertModel>{
        val type = object  : TypeToken<List<DessertModel>>() {}.type
        return Gson().fromJson(json, type)
    }
     */

    //*************************SUPLEMENTS
    @TypeConverter
    fun fromSupplementsToJson(supplements:List<SupplementModel>) :String {
        val type = object  : TypeToken<List<SupplementModel>>() {}.type
        return  Gson().toJson(supplements, type)
    }

    @TypeConverter
    fun toSupplementList(json:String):List<SupplementModel>{
        val type = object  : TypeToken<List<SupplementModel>>() {}.type
        return Gson().fromJson(json, type)
    }
//*************************FLAVORS
    @TypeConverter
    fun fromFlavorsToJson(flavors:List<FlavorModel>) :String {
        val type = object  : TypeToken<List<FlavorModel>>() {}.type
        return  Gson().toJson(flavors, type)
    }

    @TypeConverter
    fun toFlavorsList(json:String):List<FlavorModel>{
        val type = object  : TypeToken<List<FlavorModel>>() {}.type
        return Gson().fromJson(json, type)
    }
//************************FOOOD ORDER :orden de comida completa con supplements
    @TypeConverter
    fun fromFoodOrderToJson(foodOrderModel: FoodOrderModel) :String {
        val type = object  : TypeToken<FoodOrderModel>() {}.type
        return  Gson().toJson(foodOrderModel, type)
    }

    @TypeConverter
    fun toFoodOrder(json:String):FoodOrderModel{
        val type = object  : TypeToken<FoodOrderModel>() {}.type
        return Gson().fromJson(json, type)
    }

    //************************DRINK ORDER: orden de bebidas completa si selecciono almenos una
    @TypeConverter
    fun fromDrinkOrderToJson(drinkOrderModel: DrinkOrderModel) :String {
        val type = object  : TypeToken<DrinkOrderModel>() {}.type
        return  Gson().toJson(drinkOrderModel, type)
    }

    @TypeConverter
    fun toDrinkOrder(json:String):DrinkOrderModel{
        val type = object  : TypeToken<DrinkOrderModel>() {}.type
        return Gson().fromJson(json, type)
    }
    //************************DESSERT ORDER:orden de dessert con flavors
    @TypeConverter
    fun fromDessertOrderToJson(dessertOrderModel: DessertOrderModel) :String {
        val type = object  : TypeToken<DessertOrderModel>() {}.type
        return  Gson().toJson(dessertOrderModel, type)
    }

    @TypeConverter
    fun toDessertOrder(json:String):DessertOrderModel{
        val type = object  : TypeToken<DessertOrderModel>() {}.type
        return Gson().fromJson(json, type)
    }
}