package com.example.foodapp.data.local

import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.example.foodapp.data.local.converters.FoodConverter
import com.example.foodapp.data.local.dao.*
import com.example.foodapp.data.local.models.*

//base de datos: punto de acceso principal para la conexion a los datos persistentes de la app
@Database(
    entities = [
        SupplementModel::class,
        FlavorModel::class,
        FoodModel::class, //tablas de la base de datos
        DrinkModel::class,
        DessertModel::class,
        CheckoutModel::class], //le pasamos nuestras clases modelos a la base
    version = 1,
    exportSchema = false
)
//proporciona instancias de los DAOs asociados
@TypeConverters(FoodConverter::class)  //le pasamos nuestros convertores
abstract class AppDatabase : RoomDatabase() {  //base de datos de tipo rooom, declaracion
//una clase abstracta con funciones abstractas
    abstract fun supplementDao(): SupplementDao
    abstract fun flavorDao(): FlavorDao
    abstract fun foodDao(): FoodDao //funciones que interactuan con los datos, tipo Dao
    abstract fun drinkDao(): DrinkDao
    abstract fun dessertDao(): DessertDao
    abstract fun checkoutDao(): CheckoutDao
}