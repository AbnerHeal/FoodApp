package com.example.foodapp.presentation.ui.drink

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.core.view.isGone
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.foodapp.R
import com.example.foodapp.data.entities.DrinkEntity
import com.example.foodapp.data.entities.FoodEntity
import com.example.foodapp.data.mapers.toParcelable
import com.example.foodapp.databinding.FragmentDrinkBinding
import com.example.foodapp.databinding.FragmentFoodBinding
import com.example.foodapp.presentation.models.Drink
import com.example.foodapp.presentation.ui.food.FoodAdapter
import com.example.foodapp.presentation.ui.food.FoodFragmentDirections
import com.example.foodapp.presentation.ui.food.FoodViewModel
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class DrinkFragment : Fragment(), DrinkAdapter.OnClickListener {

    private var _binding: FragmentDrinkBinding? = null
    private val binding get() = _binding!!

    private val viewModel: DrinkViewModel by viewModels()//instancia del view model(lo inyectamos)
    private val drinkAdapter = DrinkAdapter(this)
    private val drinks = arrayListOf<DrinkEntity>()


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentDrinkBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        viewModel.getDrinks()
        setupObservers()
        prepareUI()
    }

    private fun setupObservers() = with(viewModel) {
        drinks.observe(viewLifecycleOwner, ::loadDrinks) //reflection
        //observa el livedata
        isLoading.observe(viewLifecycleOwner){ isLoading-> //observa si hay un cambio en isloading
            binding.progressBar.isGone = !isLoading //se ira o vendra cuando el valor cambie
        }
    }

    private fun loadDrinks(drinks: List<DrinkEntity>) {
        drinkAdapter.addDrinks(drinks)
    }

    private fun prepareUI() = with(binding) {
        rvDrinks.setupForDrinks()
        tvDone.setOnClickListener { goToCheckout() }
    }

    private fun RecyclerView.setupForDrinks() {
        layoutManager = GridLayoutManager(requireContext(), 3)
        adapter = drinkAdapter
    } //todas las funciones de extencion van en mayuscula inicial

    override fun onClick(drinkEntity: DrinkEntity) = with(viewModel) {
        onSaveDrink(drinkEntity)//guarda el o los items (mismo proceso de suppelemnts
        onDrinkClicked(drinkEntity)
    }

    /*private fun addDrink(drinkEntity: DrinkEntity) {
        val isAdded = drinks.any { drink -> drink.id == drinkEntity.id }
        if (isAdded) drinks.remove(drinkEntity)
        else drinks.add(drinkEntity)
    }*/

    private fun goToCheckout() = with(DrinkFragmentDirections) {
        findNavController().navigate(
            DrinkFragmentDirections.actionFragmentDrinkToNavReady()
        )
    }
    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}