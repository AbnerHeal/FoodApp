package com.example.foodapp.data.local.models

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.foodapp.data.models.FlavorDto

@Entity
data class DessertModel (
    @PrimaryKey
    val id:String,
    val name:String,
    val price: Float,
    val image:String,
    val flavors: List<FlavorModel>?=null
)