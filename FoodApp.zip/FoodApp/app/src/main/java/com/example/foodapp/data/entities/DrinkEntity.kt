package com.example.foodapp.data.entities

import com.google.gson.annotations.SerializedName

data class DrinkEntity(
    val id:String,
    val name:String,
    val price:Number,
    val image:String,
    var isClicked:Boolean = false //para saber si el objeto fue selecccionado
)
