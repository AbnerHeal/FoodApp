package com.example.foodapp.presentation.ui.drink

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.example.foodapp.R
import com.example.foodapp.data.entities.DrinkEntity
import com.example.foodapp.data.entities.FoodEntity
import com.example.foodapp.databinding.ItemFoodBinding
import com.example.foodapp.presentation.ui.food.FoodAdapter
import com.example.foodapp.presentation.ui.food.FoodViewHolder
import com.example.foodapp.ui_ktx.loadUrl

class DrinkViewHolder (
    private val binding: ItemFoodBinding
    ): RecyclerView.ViewHolder(binding.root){

        companion object{
            fun create(parent: ViewGroup): DrinkViewHolder {
                val inflater= LayoutInflater.from(parent.context)
                val view= ItemFoodBinding.inflate(inflater,parent, false)
                return DrinkViewHolder(view)
            }
        }
        private val context=itemView.context
        fun bindTo(drinkEntity: DrinkEntity,listener: DrinkAdapter.OnClickListener) = with(binding){// va a trabajar con binding, para ya no poner la palabra binding cada que llamo algo
            tvName.text = drinkEntity.name
            tvPrice.text= "${drinkEntity.price.toString()}"
            ivFood.loadUrl(drinkEntity.image)
            drinkEntity.onClick(listener)
            drinkEntity.setClickedCard()
        }

    private fun DrinkEntity.setClickedCard() = with(binding){
        when(isClicked){
            true -> cvFood.setCardBackgroundColor(context.getColorResources(R.color.yellow))
            false -> cvFood.setCardBackgroundColor(context.getColorResources(R.color.white))
        }
    }

    private fun Context.getColorResources(color:Int): Int {
        return ContextCompat.getColor(this,color)
    }

    private fun DrinkEntity.onClick(listener: DrinkAdapter.OnClickListener) = with(binding){
        cvFood.setOnClickListener {
            listener.onClick(this@onClick)
        }
    }
}