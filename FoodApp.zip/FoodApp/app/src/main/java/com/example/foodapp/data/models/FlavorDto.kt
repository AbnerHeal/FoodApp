package com.example.foodapp.data.models

import com.google.gson.annotations.SerializedName

data class FlavorDto( //los flavors no tienen precio segun el apirest
    @SerializedName("_id") val id: String,
    @SerializedName("name") val name: String,
    @SerializedName("image") val image: String
)
