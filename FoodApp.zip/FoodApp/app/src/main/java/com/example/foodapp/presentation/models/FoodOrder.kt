package com.example.foodapp.presentation.models

import android.os.Parcelable
import com.example.foodapp.data.entities.FoodEntity
import kotlinx.parcelize.Parcelize

@Parcelize
data class FoodOrder(
    val foods: List<String>? = null,
): Parcelable
