package com.example.foodapp.data.local.models

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.foodapp.data.models.SupplementDto

@Entity //Entidades del room: representan tablas de la base datos
data class FoodModel (
    @PrimaryKey(autoGenerate = true) //le pedimos que autogenere la clave primaria
    val uuid:Int = 0, //id autoincrementable: identificador del modelo (en este caso se genera solo)
    val id: String,
    val name: String,
    val price: Float,
    val image: String,
    val supplements: List<SupplementModel>? = null //entran supplements para acompanar a la comida
)//puede usar las entidades a fin de actualizar filas de las tablas correspondientes o crear filas nuevas para su inserción
