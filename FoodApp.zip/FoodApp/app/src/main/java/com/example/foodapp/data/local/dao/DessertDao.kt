package com.example.foodapp.data.local.dao

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.foodapp.data.local.models.DessertModel

@Dao //acceso a la base de datos para room
interface DessertDao { //interfaz para los desserts

    @Query("Select * From DessertModel") //obtiene la lista de objetos dessert
    fun getDesserts(): LiveData<List<DessertModel>> //regresa un

    @Insert(onConflict = OnConflictStrategy.REPLACE)//inserta los dessert seleccionados
    suspend fun insert(dessert: DessertModel)

    @Query("DELETE FROM DessertModel") //limpia la seleccion
    suspend fun clearDesserts()

    @Query("DELETE FROM DessertModel where id=:id") //borra por id
    suspend fun deleteDessertById(id:String)
}