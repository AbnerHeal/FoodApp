package com.example.foodapp.data.models

import com.google.gson.annotations.SerializedName

//DTO:data transfer object
//transfiere atributos de un objeto entre el cliente y el servidor (retrofit)

data class FoodDto( //lo convertimos a objeto por eso el serialized y tambien para poder cambiar el nombre si se desea
    //como se encuentra en el API REST vs como lo quiero en mi APP
    @SerializedName("_id") val id:String,
    @SerializedName("name") val name:String,
    @SerializedName("price") val price:Number,
    @SerializedName("image") val image:String,
    @SerializedName("supplements") val supplements:List<SupplementDto>?=null //por si viene nulo el array (no selecciono ningun item supplememt)
)
