package com.example.foodapp.data.local.dao

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.foodapp.data.local.models.FoodModel
//objetos de acceso a datos
@Dao // DATA ACCESS OBJECT acceso a la base de datos para obtener caracteristicas de objetos
//proporciona metodos que puedo usar como consultar, actualizar, insertar, borrar datos
interface FoodDao {
    @Query("Select * From FoodModel")
    fun getFoods(): LiveData<List<FoodModel>> //visualizacion de la lista de foods RV

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(food:FoodModel) //corrutinas, inserta cuando se selecciona item

    @Query("DELETE FROM FoodModel")
    suspend fun clearFoods() //limpia cuando se deselecciona el item

    @Query("DELETE FROM FoodModel where id=:id")
    suspend fun deleteFoodById(id:String) //borra por id, para el checkout
}//puede usar los DAOs para recuperar datos de la base de datos como instancias de objetos de entidad de datos asociados