package com.example.foodapp.presentation.models

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class Drink(
    val id:String,
    val name:String,
    val price:Number,
    val image:String,
    var isClicked:Boolean = false
):Parcelable
