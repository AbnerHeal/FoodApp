package com.example.foodapp.data.entities

import com.example.foodapp.data.models.DessertDto
import com.google.gson.annotations.SerializedName

data class DessertOrderEntity(
    val desserts: List<String>? = null //se le anade una lista de ids de objetos dessert que el usuario escoge
)