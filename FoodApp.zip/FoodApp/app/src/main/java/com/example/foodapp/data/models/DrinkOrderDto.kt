package com.example.foodapp.data.models

import com.google.gson.annotations.SerializedName

data class DrinkOrderDto (
    @SerializedName("drinks") val drinks: List<String>?=null,
        )