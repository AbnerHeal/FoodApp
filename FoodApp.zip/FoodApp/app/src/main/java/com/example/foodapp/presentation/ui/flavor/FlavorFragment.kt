package com.example.foodapp.presentation.ui.flavor

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.foodapp.data.entities.FlavorEntity
import com.example.foodapp.data.mapers.toEntity
import com.example.foodapp.databinding.FragmentFlavorBinding
import com.example.foodapp.ui_ktx.loadUrl
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class FlavorFragment : Fragment(), FlavorAdapter.OnClickListener {

    private var _binding: FragmentFlavorBinding?=null
    private val binding get() = _binding!!

    private val viewModel: FlavorViewModel by viewModels()//instancia del view model(lo inyectamos)
    private val favorAdapter= FlavorAdapter(this)
    private val args: FlavorFragmentArgs by navArgs()
    private val flavors=arrayListOf<FlavorEntity>()//es lo que pasare

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentFlavorBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        viewModel.getFlavors()
        setupObservers()
        prepareUI()
        prepareArgs()
    }

    private fun prepareArgs() = with(binding){
        ivItemDessertSelect.loadUrl(args.dessert.image)
    }

    private fun setupObservers()= with(viewModel){
        flavors.observe(viewLifecycleOwner, ::loadFlavors) //reflection
        //observa el livedata
        isSaved.observe(viewLifecycleOwner){isSaved->
            if(isSaved){
                goToCheckout()
            }
        }
    }

    private fun prepareUI()= with(binding){
        rvFlavor.setupForFlavors()
        clNext.setOnClickListener {
            viewModel.onSaveDessert(
                args.dessert.toEntity(),
                flavors
            )
        }
    }

    private fun loadFlavors(flavors:List<FlavorEntity>){
        favorAdapter.addFlavors(flavors)
    }

    private fun RecyclerView.setupForFlavors(){
        layoutManager= LinearLayoutManager(requireContext())
        adapter=favorAdapter
    } //todas las funciones de extencion van en mayuscula inicial

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    override fun onClick(flavorEntity: FlavorEntity)=with(viewModel){
        addFlavor(flavorEntity)
        onFlavorClicked(flavorEntity)
    }

    private fun addFlavor(flavorEntity: FlavorEntity){
        val isAdded=flavors.any{ flavor -> flavor.id == flavorEntity.id}
        if(isAdded) flavors.remove(flavorEntity)
        else flavors.add(flavorEntity)
    }

    private fun goToCheckout()=with(FlavorFragmentDirections){
        findNavController().navigate(
            FlavorFragmentDirections.actionFragmentFlavorToNavReady()
        )
    }
}