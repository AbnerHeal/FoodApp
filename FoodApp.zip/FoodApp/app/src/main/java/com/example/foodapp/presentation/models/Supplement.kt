package com.example.foodapp.presentation.models

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class Supplement(
    val id: String, //lo convertimos a objeto por eso el serialized
    val name: String,
    val price: Number,
    val image: String,
    var isClicked: Boolean = false
):Parcelable