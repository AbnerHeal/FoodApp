package com.example.foodapp.data.models

import com.google.gson.annotations.SerializedName

data class FoodOrderDto(
    @SerializedName("foods") val foods: List<String>?=null //una lista de ids de mis foods seleccionados
)
