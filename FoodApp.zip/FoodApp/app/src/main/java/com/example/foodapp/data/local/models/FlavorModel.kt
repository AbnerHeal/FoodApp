package com.example.foodapp.data.local.models

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity
data class FlavorModel(
    @PrimaryKey
    val id: String,
    val name: String,
    val image: String
)