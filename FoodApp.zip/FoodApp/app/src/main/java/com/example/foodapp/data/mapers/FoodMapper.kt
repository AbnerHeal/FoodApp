package com.example.foodapp.data.mapers

import com.example.foodapp.data.entities.*
import com.example.foodapp.data.local.models.*
import com.example.foodapp.data.models.*
import com.example.foodapp.presentation.models.*

//mapers de principio solid, podemos usart mappers dentro de mappers

//MAPPER GENERALES DE TODA LA APP ***************para pasar objetos entre fragments
//para aplicar funciones que transformen elementos de una coleccion y el contenido adquiera las cualidades de lo que se esta transformando

//funciones de extencion:simplifica para ahorrar codigo
//***********************************************DESSERTS********************************************
//de Dto a Entity
fun DessertDto.toEntity() = DessertEntity(
    id = id, //igualamos nuestro entity a el data transfer object
    name = name,
    price = price.toFloat(),
    image = image,
    flavors = flavors?.map { it.toEntity() }//se anade esto cuando se usa list
)

//de Entity a Dto
fun DessertEntity.toDto() = DessertDto(
    id = id,
    name = name,
    price = price,
    image = image,
    flavors = flavors?.map { it.toDto() }
)
//Mapeamos Model - Entity para ROOM *************************
fun DessertModel.toEntity() = DessertEntity(
    id = id,
    name = name,
    price = price,
    image = image,
    flavors = flavors?.map { it.toEntity() }
)
 //de entity a model
fun DessertEntity.toModel() = DessertModel(
    id = id,
    name = name,
    price = price.toFloat(),
    image = image,
    flavors = flavors?.map { it.toModel() }
)
//*************** PARA NAVIGATION *****************
fun Dessert.toEntity() = DessertEntity(
    id = id,
    name = name,
    price = price,
    image = image,
    flavors = flavors?.map { it.toEntity() }
)

fun DessertEntity.toParcelable() = Dessert(
    id = id,
    name = name,
    price = price.toFloat(),
    image = image,
    flavors = flavors?.map { it.toParcelable() }
)
//***********************************************FOODS*******************************************
//ES MEJOR HACER UN ARCHIVO POR CADA CONVERSION
fun FoodDto.toEntity() = FoodEntity(
    id = id,
    name = name,
    price = price,
    image = image,
    supplements = supplements?.map { it.toEntity() }
)

fun FoodEntity.toDto() = FoodDto(
    id = id,
    name = name,
    price = price,
    image = image,
    supplements = supplements?.map { it.toDto() }
)
//ES MEJOR HACER UN ARCHIVO POR CADA CONVERSION *******ROOM*********
fun FoodModel.toEntity() = FoodEntity(
    id = id,
    name = name,
    price = price,
    image = image,
    supplements = supplements?.map { it.toEntity() }
)

fun FoodEntity.toModel() = FoodModel(
    id = id,
    name = name,
    price = price.toFloat(),
    image = image,
    supplements = supplements?.map { it.toModel() }
)
//*************** PARA ... *****************
fun Food.toEntity() = FoodEntity(
    id = id,
    name = name,
    price = price.toFloat(),
    image = image,
    supplements = supplements?.map { it.toEntity() }
)

fun FoodEntity.toParcelable() = Food(
    id = id,
    name = name,
    price = price.toFloat(),
    image = image,
    supplements = supplements?.map { it.toParcelable() }
)
//***********************************************DRINKS*******************************************
//ES MEJOR HACER UN ARCHIVO POR CADA CONVERSION
fun DrinkDto.toEntity() = DrinkEntity(
    id = id,
    name = name,
    price = price,
    image = image
)

fun DrinkEntity.toDto() = DrinkDto(
    id = id,
    name = name,
    price = price,
    image = image
)
//ES MEJOR HACER UN ARCHIVO POR CADA CONVERSION *********ROOM***********
fun DrinkModel.toEntity() = DrinkEntity(
    id = id,
    name = name,
    price = price,
    image = image
)

fun DrinkEntity.toModel() = DrinkModel(
    id = id,
    name = name,
    price = price.toFloat(),
    image = image
)
//*************** PARA ... *****************
fun Drink.toEntity() = DrinkEntity(
    id = id,
    name = name,
    price = price,
    image = image
)

fun DrinkEntity.toParcelable() = Drink(
    id = id,
    name = name,
    price = price.toFloat(),
    image = image
)
//***********************************************CHECKOUTS******************************************
//ES MEJOR HACER UN ARCHIVO POR CADA CONVERSION
fun CheckoutDto.toEntity() = CheckoutEntity(
        foodOrder = foodOrder?.toEntity(), //se pasan solo asi porque se trata de un objeto de tipo lista
        drinkOrder = drinkOrder?.toEntity(),
        dessertOrder = dessertOrder?.toEntity(),
        totalPrice= totalPrice
    )

fun CheckoutEntity.toDto() = CheckoutDto(
    foodOrder = foodOrder?.toDto(),
    drinkOrder = drinkOrder?.toDto(),
    dessertOrder = dessertOrder?.toDto(),
    totalPrice= totalPrice
)
//ES MEJOR HACER UN ARCHIVO POR CADA CONVERSION ************ROOM************
fun CheckoutModel.toEntity() = CheckoutEntity(
    id = id,
    foodOrder = foodOrder?.toEntity(),
    drinkOrder = drinkOrder?.toEntity(),
    dessertOrder = dessertOrder?.toEntity(),
    totalPrice= totalPrice
)

fun CheckoutEntity.toModel() = CheckoutModel(
    id = id.toString(),
    foodOrder = foodOrder?.toModel(),
    drinkOrder = drinkOrder?.toModel(),
    dessertOrder = dessertOrder?.toModel(),
    totalPrice= totalPrice?.toDouble()
)
//*************** PARA ... *****************
fun Checkout.toEntity() = CheckoutEntity(
    id = id,
    foodOrder = foodOrder?.toEntity(),
    drinkOrder = drinkOrder?.toEntity(),
    dessertOrder = dessertOrder?.toEntity(),
    totalPrice= totalPrice
)

fun CheckoutEntity.toParcelable() = Checkout(
    id = id,
    foodOrder = foodOrder?.toParcelable(),
    drinkOrder = drinkOrder?.toParcelable(),
    dessertOrder = dessertOrder?.toParcelable(),
    totalPrice= totalPrice
)
//las que vienen para anadir
//***********************************************FLAVORS********************************************
//ES MEJOR HACER UN ARCHIVO POR CADA CONVERSION
fun FlavorDto.toEntity() = FlavorEntity(
    id = id,
    name = name,
    image = image
)

fun FlavorEntity.toDto() = FlavorDto(
    id = id,
    name = name,
    image = image
)
//************ROOM************
fun FlavorModel.toEntity() = FlavorEntity(
    id = id,
    name = name,
    image = image
)

fun FlavorEntity.toModel() = FlavorModel(
    id = id,
    name = name,
    image = image
)
//*************** PARA ... *****************
fun Flavor.toEntity() = FlavorEntity(
    id = id,
    name = name,
    image = image
)

fun FlavorEntity.toParcelable() = Flavor(
    id = id,
    name = name,
    image = image
)
//*******************************************SUPPLEMENTS********************************************
//ES MEJOR HACER UN ARCHIVO POR CADA CONVERSION
fun SupplementDto.toEntity() = SupplementEntity(
    id = id,
    name = name,
    price = price,
    image = image
)

fun SupplementEntity.toDto() = SupplementDto(
    id = id,
    name = name,
    price = price,
    image = image
)
//**********ROOM***************
fun SupplementModel.toEntity() = SupplementEntity(
    id = id,
    name = name,
    price = price,
    image = image
)

fun SupplementEntity.toModel() = SupplementModel(
    id = id,
    name = name,
    price = price.toFloat(),
    image = image
)
//*************** PARA ... *****************

fun Supplement.toEntity() = SupplementEntity(
    id = id,
    name = name,
    price = price.toFloat(),
    image = image
)

fun SupplementEntity.toParcelable() = Supplement(
    id = id,
    name = name,
    price = price.toFloat(),
    image = image
)
//Parte del Checkout
//***********************************************DESSERTS-ORDER*************************************
//ES MEJOR HACER UN ARCHIVO POR CADA CONVERSION
fun DessertOrderDto.toEntity() = DessertOrderEntity(
    desserts = desserts
)

fun DessertOrderEntity.toDto() = DessertOrderDto(
    desserts = desserts
)
//***************ROOM************
fun DessertOrderEntity.toModel() = DessertOrderModel(
    desserts = desserts
)

fun DessertOrderModel.toEntity() = DessertOrderEntity(
    desserts = desserts
)
//*************** PARA ... *****************
fun DessertOrderEntity.toParcelable() = DessertOrder(
    desserts = desserts
)

fun DessertOrder.toEntity() = DessertOrderEntity(
    desserts = desserts
)

//***********************************************DRINKS-ORDER*************************************
//ES MEJOR HACER UN ARCHIVO POR CADA CONVERSION
fun DrinkOrderDto.toEntity() = DrinkOrderEntity(
    drinks = drinks
)

fun DrinkOrderEntity.toDto() = DrinkOrderDto(
    drinks = drinks
)
//**************ROOM************
fun DrinkOrderEntity.toModel() = DrinkOrderModel(
    drinks = drinks
)

fun DrinkOrderModel.toEntity() = DrinkOrderEntity(
    drinks = drinks
)
//*************** PARA ... *****************
fun DrinkOrderEntity.toParcelable() = DrinkOrder(
    drinks = drinks
)

fun DrinkOrder.toEntity() = DrinkOrderEntity(
    drinks = drinks
)

//***********************************************FOOD-ORDER*************************************
//ES MEJOR HACER UN ARCHIVO POR CADA CONVERSION
fun FoodOrderDto.toEntity() = FoodOrderEntity(
    foods = foods
)

fun FoodOrderEntity.toDto() = FoodOrderDto(
    foods = foods
)
//************ROOM*************
fun FoodOrderEntity.toModel() = FoodOrderModel(
    foods = foods
)

fun FoodOrderModel.toEntity() = FoodOrderEntity(
    foods = foods
)
//*************** PARA ... *****************
fun FoodOrderEntity.toParcelable() = FoodOrder(
    foods = foods
)

fun FoodOrder.toEntity() = FoodOrderEntity(
    foods = foods
)

//******************************************ORDER*********************************************

//**************** PARA ROOM ***************
fun OrderModel.toEntity() = OrderEntity(
    id = id,
    name = name,
    price = price,
    image = image,
    supplements = supplements?.map { it.toEntity() }
)

fun OrderEntity.toModel() = OrderModel(
    id = id,
    name = name,
    price = price,
    image = image,

    supplements = supplements?.map { it.toModel() }
)
//*************** PARA ... *****************
fun Order.toEntity() = OrderEntity(
    id = id,
    name = name,
    price = price,
    image = image,
    supplements = supplements?.map { it.toEntity() }
)

fun OrderEntity.toParcelable() = Order(
    id = id,
    name = name,
    price = price,
    image = image,
    supplements = supplements?.map { it.toParcelable() }
)


//********PARA ANADIR A LA ORDEN LOS ITEMS SELECCIONADOS***********
fun FoodEntity.toOrder() = OrderEntity(
    id = id,
    name = name,
    price = price,
    image = image,
    supplements = supplements
)

fun DrinkEntity.toOrder() = OrderEntity(
    id = id,
    name = name,
    price = price,
    image = image,
)

fun DessertEntity.toOrder() = OrderEntity(
    id = id,
    name = name,
    price = price,
    image = image,
)