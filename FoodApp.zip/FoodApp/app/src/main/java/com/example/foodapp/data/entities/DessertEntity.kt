package com.example.foodapp.data.entities

import com.example.foodapp.data.models.FlavorDto
import com.google.gson.annotations.SerializedName

data class DessertEntity(
    val id:String,
    val name:String,
    val price: Float,
    val image:String,
    var flavors: List<FlavorEntity>?=null, //le entra unba lista de objs tipo flavors,
    // para cargar atributos en vista (imagen, name)
    var isClicked:Boolean = false //para saber que objeto fue seleccionado
)