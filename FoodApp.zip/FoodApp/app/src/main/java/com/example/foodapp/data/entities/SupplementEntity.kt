package com.example.foodapp.data.entities


data class SupplementEntity(
    val id: String,
    val name: String,
    val price: Number,
    val image: String,
    var isClicked:Boolean = false//para saber que supplements escoge
)