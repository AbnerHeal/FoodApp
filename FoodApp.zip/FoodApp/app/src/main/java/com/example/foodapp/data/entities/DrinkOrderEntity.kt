package com.example.foodapp.data.entities

import com.example.foodapp.data.models.DrinkDto
import com.google.gson.annotations.SerializedName

data class DrinkOrderEntity( //objeto de la suma de drinks que el usuario escoja,
// para meterla despues al checkout
    val drinks: List<String>? = null, //solo contiene los drnks, que es una lista que se anade por id
)