package com.example.foodapp.presentation.components.camera

import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.lifecycle.LifecycleOwner
import com.example.foodapp.ui_ktx.buildDefaultImageAnalyzer
import com.example.foodapp.ui_ktx.buildDefaultImageCapture
import com.example.foodapp.ui_ktx.buildDefaultPreview
import com.example.foodapp.ui_ktx.createSurfaceProvider
import java.util.concurrent.Executor
import java.util.concurrent.TimeUnit

//clase para inicializar la camara
class CameraPreview private constructor(builder: Builder) {
    companion object {
        private const val DURATION = 1.toLong()
    }

    private val process = builder.process
    private val view = builder.view
    private val cameraSelector = CameraSelector.Builder().requireLensFacing(builder.lensFacing).build()
    private val preview = builder.preview
    private val imageAnalysis = builder.imageAnalysis
    val imageCapture = builder.imageCapture //constructor para capturar una foto
    lateinit var controller: CameraControl
    var cameraInfoValue: CameraInfo? = null

    fun setAnalyzer(executor: Executor, analyzer: ImageAnalysis.Analyzer) =
        imageAnalysis.setAnalyzer(executor, analyzer)

    fun bindToLifecycle(lifecycleOwner: LifecycleOwner): Camera {
        preview.createSurfaceProvider(view)
        process.unbindAll()
        return process.bindToLifecycle(lifecycleOwner, cameraSelector, preview, imageCapture).apply {
            autoFocus(view)
            setControllerAndCameraInfo()
        }
    }

    private fun Camera.autoFocus(view: PreviewView) {
        val width = view.width.toFloat()
        val height = view.height.toFloat()

        val factory: MeteringPointFactory = SurfaceOrientedMeteringPointFactory(width, height)
        val centerWidth = width / 2
        val centerHeight = height / 2
        val autoFocusPoint = factory.createPoint(centerWidth, centerHeight)

        try {
            val focusMeteringAction = FocusMeteringAction.Builder(
                autoFocusPoint,
                FocusMeteringAction.FLAG_AF
            ).apply {
                setAutoCancelDuration(DURATION, TimeUnit.SECONDS)
            }.build()
            cameraControl.startFocusAndMetering(focusMeteringAction)
        } catch (ex: CameraInfoUnavailableException) {
        }
    }


    private fun Camera.setControllerAndCameraInfo() {
        controller = cameraControl
        cameraInfoValue = cameraInfo
    }

    fun stop() {
        process.unbindAll()
    }

    @Suppress("unused")
    class Builder(val process: ProcessCameraProvider, val view: PreviewView) {
        var lensFacing = CameraSelector.LENS_FACING_BACK; private set
        var preview = view.buildDefaultPreview(); private set
        var imageAnalysis = view.buildDefaultImageAnalyzer(); private set
        var imageCapture = view.buildDefaultImageCapture(); private set

        fun setLensFacing(@CameraSelector.LensFacing lensFacing: Int) = this.apply { this.lensFacing = lensFacing }

        fun setPreview(preview: Preview): Builder = this.apply { this.preview = preview }

        fun setImageAnalysis(imageAnalysis: ImageAnalysis): Builder = this.apply { this.imageAnalysis = imageAnalysis }

        fun build() = CameraPreview(this)
    }
}