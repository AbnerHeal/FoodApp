package com.example.foodapp.data.local.dao

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.foodapp.data.local.models.CheckoutModel
import com.example.foodapp.data.local.models.DessertModel
import com.example.foodapp.data.local.models.SupplementModel


//DAO: DATA ACCESS OBJECT (PATRON DE DISEÑO) acceso a base de datos
//para el acceso de datos de room
@Dao //transfiere atributos de los objetos entre el cliente y el servidor interaccion

interface CheckoutDao {//los dao se definen como una interface (casos de uso basico)
//notacion para que room pueda reconocerlo

    @Query("Select * From CheckoutModel") //funcion para leer los checkouts
    fun getCheckouts(): LiveData<List<CheckoutModel>> //devueleve una lista de tipo checkoutmodel con el observer

    @Insert(onConflict = OnConflictStrategy.REPLACE) //remplaza los datos antiguos y continua la transaccion
    suspend fun insert(checkout: CheckoutModel) //inserta el checkuot que recibe del usuario (los obj q escogio)

    @Query("DELETE FROM CheckoutModel") //borra todos los datos del checkout
    suspend fun clearCheckout()//usamos corrutines por eso el suspend

    @Query("DELETE FROM CheckoutModel where id=:id")
    suspend fun deleteCheckoutById(id:String) //borra objetos buscandolos por el id
}