package com.example.foodapp.data.local.dao

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.foodapp.data.local.models.FlavorModel

@Dao
interface FlavorDao {
    @Query("Select * From FlavorModel")
    fun getFlavors(): LiveData<List<FlavorModel>> //trae la lista de sabores con livedatta

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(flavor:FlavorModel) //inserta el flavor seleccionado

    @Query("DELETE FROM FlavorModel")
    suspend fun clearFlavors() //borra flavor si se selecciona de nuevo

    @Query("DELETE FROM FlavorModel where id=:id")
    suspend fun deleteFlavorById(id:String) //cuando se limpia el checkout
}