package com.example.foodapp.data.local.dao

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.foodapp.data.local.models.DrinkModel

@Dao
interface DrinkDao {
    @Query("Select * From DrinkModel")
    fun getDrinks(): LiveData<List<DrinkModel>>

    //es unico que tiene esta funcion debido a que se puede escoger mas de uno

    @Query("Select * From DrinkModel where id=:id")// obtiene las caracrteristicas del objeto drink por el id
    fun getDrinkById(id:String): DrinkModel //devuelve un objeto drink de tipo model

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(drink:DrinkModel)

    @Query("DELETE FROM DrinkModel")
    suspend fun clearDrinks()

    @Query("DELETE FROM DrinkModel where id=:id")
    suspend fun deleteDrinkById(id:String)
}