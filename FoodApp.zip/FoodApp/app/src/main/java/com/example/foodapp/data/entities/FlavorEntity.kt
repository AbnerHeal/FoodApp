package com.example.foodapp.data.entities

import com.google.gson.annotations.SerializedName

data class FlavorEntity(
    val id: String,
    val name: String,
    val image: String,
    var isClicked:Boolean = false //para identificar cuando el objeto fue seleccionado (el sabor)
)