package com.example.foodapp.data.local.models

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.foodapp.data.models.DessertDto

@Entity
data class DessertOrderModel (
    @PrimaryKey
    val desserts: List<String>? = null, // lista de ids de dessserts
    )