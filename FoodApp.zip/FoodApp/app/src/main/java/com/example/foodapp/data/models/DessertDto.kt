package com.example.foodapp.data.models

import com.google.gson.annotations.SerializedName

data class DessertDto(
    @SerializedName("_id") val id:String,
    @SerializedName("name") val name:String,
    @SerializedName("price") val price: Number,
    @SerializedName("image") val image:String,
    @SerializedName("flavors") val flavors: List<FlavorDto>?=null //entra una lista de objetos tipo flavor
)
