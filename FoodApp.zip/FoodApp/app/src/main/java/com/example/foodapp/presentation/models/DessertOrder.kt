package com.example.foodapp.presentation.models

import android.os.Parcelable
import com.example.foodapp.data.entities.DessertEntity
import kotlinx.parcelize.Parcelize

@Parcelize
data class DessertOrder(
    val desserts: List<String>? = null,
): Parcelable
