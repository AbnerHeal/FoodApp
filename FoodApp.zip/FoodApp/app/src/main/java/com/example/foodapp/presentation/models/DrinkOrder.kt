package com.example.foodapp.presentation.models

import android.os.Parcelable
import com.example.foodapp.data.entities.DrinkEntity
import kotlinx.parcelize.Parcelize

@Parcelize
data class DrinkOrder(
    val drinks: List<String>? = null,
): Parcelable
