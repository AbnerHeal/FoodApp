package com.example.foodapp.data.models

import com.google.gson.annotations.SerializedName

data class DessertOrderDto(
    @SerializedName("desserts") val desserts: List<String>?=null // la orden de desserts es una lista de ids dessert
)
