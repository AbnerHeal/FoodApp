package com.example.foodapp.data.entities

import com.example.foodapp.ui_ktx.asCurrency
import com.example.foodapp.ui_ktx.numberFormatter

//PARA LA ORDEN DE COMIDA CON LA LISTA DE SUPLEMENTOS
data class OrderEntity(
    val id: String,
    val name: String,
    val price: Number,
    val image: String,
    val supplements: List<SupplementEntity>? = null
) {

    //la siguiente funcion solo se ocupa en foods,
    // debido a que tiene diferentes precios de supplements y puede escoger ninguno o los que desee

    val totalPrice:String //para calcular el precio total ya con supplements
    get() { // se obtiene de la siguiente manera
        var price_total = 0.0 //inicializamos costo extra, var porque aumenta
        price_total = if (supplements.isNullOrEmpty()){ //sera cero sino hay nada o es null
            0.0
        }else{
            supplements.sumOf{ it.price.toDouble() } //precio a anadir sera la suma de los precios de suplements seleccionados
        }
        return (price.toDouble() + price_total).toString().asCurrency() //retorna el precio del objeto mas lo que se sumo en supplements
    }
}
