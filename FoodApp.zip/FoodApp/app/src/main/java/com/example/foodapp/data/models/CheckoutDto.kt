package com.example.foodapp.data.models

import com.google.gson.annotations.SerializedName
import java.nio.ByteOrder

//DTO:data transfer object
//transfiere atributos de un objeto entre el cliente y el servidor (retrofit) metodos setter y getter
//sirve como clase POJO
data class CheckoutDto( //lo convertimos a objeto por eso el serialized y tambien para poder cambiar el nombre si se desea
    //como se encuentra en el API REST vs como lo quiero en mi APP
    @SerializedName("foodOrder") val foodOrder:FoodOrderDto?=null,
    @SerializedName("drinksOrder") val drinkOrder:DrinkOrderDto?=null,
    @SerializedName("dessertOrder") val dessertOrder:DessertOrderDto?=null,
    @SerializedName("totalPrice") val totalPrice:Number?=null,
)