package com.example.foodapp.presentation.ui.flavor

import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.foodapp.data.entities.FlavorEntity
import com.example.foodapp.ui_ktx.notifyChanged

class FlavorAdapter(
    private val listener: OnClickListener
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    private var flavors: List<FlavorEntity> by notifyChanged(
        areContentsTheSame = { old, new -> old.isClicked != new.isClicked } //notifica cambios cuando old y new sean diferentes
    )

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FlavorViewHolder =
        FlavorViewHolder.create(parent)

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        if (holder is FlavorViewHolder) {
            val flavor = flavors[position]
            holder.bindTo(flavor, listener)
        }
    }

    override fun getItemCount(): Int = flavors.size

    fun addFlavors(flavors: List<FlavorEntity>) {
        this.flavors = flavors
    }

    interface OnClickListener {
        fun onClick(flavorEntity: FlavorEntity)
    }
}