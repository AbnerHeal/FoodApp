package com.example.foodapp.presentation.models

import android.os.Parcelable
import com.example.foodapp.data.entities.DessertOrderEntity
import com.example.foodapp.data.entities.DrinkOrderEntity
import com.example.foodapp.data.entities.FoodOrderEntity
import kotlinx.parcelize.Parcelize

@Parcelize //se genera automáticamente una implementación Parcelable
data class Checkout(
    val id: String?="",
    val foodOrder: FoodOrder?=null,
    val drinkOrder: DrinkOrder?=null,
    val dessertOrder: DessertOrder?=null,
    val totalPrice:Number?=null
):Parcelable //siempre se anade

//requiere que todas las propiedades serializadas se declaren en el constructor principal (dataclass, constructor)