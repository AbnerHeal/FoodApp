package com.example.foodapp.data.entities

import com.example.foodapp.data.local.models.SupplementModel
import com.example.foodapp.data.models.SupplementDto
import com.google.gson.annotations.SerializedName
//ENTIDADES PRINCIPALES DE LA APP EN GENERAL
//solo estas llevan el clicked
data class FoodEntity(
    val id: String,
    val name: String,
    val price: Number,
    val image: String,
    var supplements: List<SupplementEntity>? = null, //le entra una lista de supplements con todos
    // sus atributos porque necesitamos mostrarlos (name, image, price)
    var isClicked:Boolean = false //para pintar e insertar
)