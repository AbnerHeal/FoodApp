package com.example.foodapp.data.models

import com.google.gson.annotations.SerializedName

//son inmutables siempre

data class SupplementDto( //data transfer object (se encarga de tranferir datos)
    @SerializedName("_id") val id:String, //lo convertimos a objeto por eso el serialized
    @SerializedName("name") val name:String,
    @SerializedName("price") val price:Number,
    @SerializedName("image") val image:String
)
