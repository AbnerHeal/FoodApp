package com.example.foodapp

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

//CLASE DE APLICACION DE HILT
//PUNTO DE PARTIDA DE LA APP
@HiltAndroidApp //le decimos que esta clase sea nuestro contenedor grafico de hilt (Kapt)
//activa la generacion de codigo de Hilt
class App:Application() { //extendemos de application porque lo primero que
// inicia no es el main, sino application que hostea toda la app (se ve en el manifest)
}
//se guarda aqui debido al ciclo de vida del activity,
// para que no se caigan las dependencias cuando mueran las activitys o los fragments